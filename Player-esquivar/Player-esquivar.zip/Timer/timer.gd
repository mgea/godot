extends Timer
var tiempo = 15

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	start()

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_timeout() -> void:
	print(tiempo)
	tiempo = tiempo - 1 
	$Label.text = "Tiempo restante: "+ str(tiempo)
	if tiempo == 0:
		$Label.text = "Acabado tiempo "
		stop()
