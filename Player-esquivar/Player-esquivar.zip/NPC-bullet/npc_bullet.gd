extends CharacterBody2D

@export var speedmin = 30
@export var speedmax = 130
var speed = 0
var direccion = 1
var puede_mover = true
var tiempo = 10
var velocidad_random 


func _ready() -> void:
	speed = randf_range(speedmin, speedmax)
	print (speed)
	

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if puede_mover:
		velocity.x = direccion * speed
	else:
		velocity.x = 0

	var col = move_and_collide(velocity * delta)

	if col:
		# parar y esperar
		direccion *= -1
		# puede_mover = false
		# $Timer.start()

	move_and_slide()
