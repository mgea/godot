







### UI_quizz.tscn 

Panel que muestra preguntas y calcula resultado 

Es una escena que se carga como panel de control y se superpone en la escena 

Además es responsive, se adapta a la pantalla 

Contiene un sistema muy sencillo de cargar los datos en quizz_ui.gd

Importante: 

* variable que define total de preguntas : var total_preguntas = 3 

* variable que cuenta aciertos: aciertos = 0

* Las preguntas se van cargando en una funcion cargar_preguntas() 

  usando  un "if" 
