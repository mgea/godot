extends Node2D


@onready var ui = $CanvasLayer
var abierto = true

func _ready() -> void:
	pass # Replace with function body.


# Abre el panel de objetos con tecla de espacio
func _process(delta: float) -> void:
	if Input.is_action_just_pressed("ui_accept"): # normalmente ESPACIO
		# conmuta abierto/cerrado	
		abierto = !abierto 
		# muestra o no 
		ui.visible = abierto
	if abierto:
		actualizar_ui()




func actualizar_ui():
	# elimono los actuales
	var offset_x = 70
	var start_pos = Vector2(20, 20)
	var i=0
	for c in $CanvasLayer/Panel.get_children():
		c.queue_free()
	# pongo los recolectados
	for item in Inventario.items:
		var icon = TextureRect.new()
		icon.texture = load("res://assets/" + item + ".png")
		icon.custom_minimum_size = Vector2(64,64)
		$CanvasLayer/Panel.add_child(icon)
		icon.position = start_pos + Vector2(offset_x * i, 0)
		i += 1
