proyecto Dialogic_open_player_key
----------------------------


Proyecto de godot con Dialogic 
- contiene el plugin (addon) de Dialogic versión 19 
- Godot v.4.6 modo Compatibilidad
	addon->dialogic v.alfa 19


Ejemplo que mueve un player y un "NPC dialogable" sin colisiones
Cuando el player "se acerca" se activa la opción de hablar pulsando tecla


### Personaje NPC Dialogable 
Señales: 
* on_area_2d_body_entered / on_area_2d_body_exited
  Detectan si el player está dentro de su "espacio" ColisionShape
  se pone una variable "player_inside = true o false"

* on_area_2d_mouse_entered / on_area_2d_mouse_exited
  Cambia de tamaño cuando se acerca mouse (no tiene más efectos)

* en _process() se hace la combrobación de pulsar tecla (mas eficiente) 
   si la variable player_inside es true

	# comprueba si pulsa ESPACIO 
	if Input.is_action_just_pressed("ui_accept") and player_inside:
		# comenzar diálogo al pulsar espacio
		print("ESPACIO")
		Dialogic.start("dialogo_oso")



PARA QUE SEA GENERICO y se pueda usar con más de un objeto dialogable, se 
aconseja USAR SEÑALES

se crean con un argumento: 
	 
	signal signal_dialogar (personaje)

se usan para emitir una señal que se usará desde el world.tscn 
	 
		signal_dialogar.emit(nombre_objeto)

EN el mundo, se instancian tantos dialogables como se quiera, 
en el script de world.gd se conectan señales para abrir dialogo 
adecuado:

# conectamos señales con una función 	
func _ready() -> void:
	# conectamos las señales de los dialogables
	$dialogable_oso.signal_dialogar.connect(_on_personaje_hablando)
	$dialogable_pingu .signal_dialogar.connect(_on_personaje_hablando)

# en esta función se indica el diálogo correspondiente
func _on_personaje_hablando(nombre):
	print("El personaje " + nombre + " ha empezado a hablar.")
	if (nombre=="oso"):
		Dialogic.start("dialogo_oso")
	# 








Mas información https://github.com/dialogic-godot/dialogic
Descaga en  https://dialogic.pro/

Qué es Dialogic y primeros pasos: https://github.com/mgea/godot/wiki/Dialogic-(Dialog-System)


Repo: https://github.com/mgea/godot/tree/main/Dialogic_open
