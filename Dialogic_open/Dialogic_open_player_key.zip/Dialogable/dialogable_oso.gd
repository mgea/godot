extends Node2D


@export var nombre_objeto:String
@export var texture:Texture2D

var player_inside = false

@export var escala_normal: Vector2 = Vector2(1, 1)
@export var escala_grande: Vector2 = Vector2(1.2, 1.2) # 20% más grande
@export var tiempo_animacion: float = 0.2
@onready var sprite = $Area2D/Sprite2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	print(texture)
	$Area2D/Sprite2D.texture = texture
	$Area2D/Sprite2D.visible = true



	
# comprueba "siempre" si se ha hecho click con el ratón para lanzar dialogo
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	# comprueba si pulsa ESPACIO 
	if Input.is_action_just_pressed("ui_accept") and player_inside:
		# comenzar diálogo al pulsar espacio
		print("ESPACIO")
		Dialogic.start("dialogo_oso")


func _on_area_2d_mouse_entered() -> void:
	var tween = create_tween()
	tween.tween_property(self, "scale", escala_grande, tiempo_animacion).set_trans(Tween.TRANS_SINE)
	print("in")
	


func _on_area_2d_mouse_exited() -> void:
	# Volvemos al tamaño original
	var tween = create_tween()
	tween.tween_property(self, "scale", escala_normal, tiempo_animacion).set_trans(Tween.TRANS_SINE)
	print("out")




func _on_area_2d_body_entered(body: Node2D) -> void:
	# ha entrado player en área 
	print("ha entrado ---> ", body.name) 
	var tween = create_tween()
	tween.tween_property(self, "scale", escala_grande, tiempo_animacion).set_trans(Tween.TRANS_SINE)
	# está dentro y se puede  pulsar ESPACIO 
	player_inside=true
	$mensaje.text="pulsa ESPACIO para hablar con " + nombre_objeto


func _on_area_2d_body_exited(body: Node2D) -> void:
	# ha salido player del área 
	print("ha salido ---> ", body.name) 
	var tween = create_tween()
	tween.tween_property(self, "scale", escala_normal, tiempo_animacion).set_trans(Tween.TRANS_SINE)
	# está fuera y NO se puede  pulsar ESPACIO 
	player_inside=false
	$mensaje.text=""
