extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	# conectamos las señales de los dialogables
	$dialogable_oso.signal_dialogar.connect(_on_personaje_hablando)
	$dialogable_pingu .signal_dialogar.connect(_on_personaje_hablando)

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_personaje_hablando(nombre):
	print("El personaje " + nombre + " ha empezado a hablar.")
	if (nombre=="oso"):
		Dialogic.start("dialogo_oso")
	if (nombre=="pingu"):
		Dialogic.start("dialogo_pingu")
	# Aquí podrías bloquear el movimiento del jugador
