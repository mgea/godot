extends Node2D


@export var imagen:Texture2D 
@export var nombre:String
@export var vidas:int



# Añadimos los datos en el personaje
func _ready() -> void:
	$Area2D/CollisionShape2D/img.texture=imagen
	$vidas.text = str(vidas)
	$nombre.text = nombre
	$vidas.visible=true
	$nombre.visible=false


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass



# funciones para mover


func _on_area_2d_body_entered(body: Node2D) -> void:
	pass
	


func _on_area_2d_body_exited(body: Node2D) -> void:
	pass
	


# funciones para activar/desactivar draggable

func _on_area_2d_mouse_entered() -> void:
	print("enter")
	$vidas.visible=true
	$nombre.visible=true
	$Area2D/CollisionShape2D/img.scale.x = 1.2
	$Area2D/CollisionShape2D/img.scale.y = 1.2
	



func _on_area_2d_mouse_exited() -> void:
	# el mouse sale del objeto (si no se esta moviendo, desactivar)
	print("exit")
	$vidas.visible=false
	$nombre.visible=false
	$Area2D/CollisionShape2D/img.scale.x = 1
	$Area2D/CollisionShape2D/img.scale.y = 1
