extends Node2D

# esta escena empieza directamente con un Dialogo 

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	Dialogic.signal_event.connect(_on_dialogic_signal)
	### falla al iniciar directamente con Dialogo 
	# Dialogic.start("dialogo_sutemo")
	

# señal emitida desde Dialogic (añadir manualmente)
func _on_dialogic_signal (argument:String):
	if argument== "ir_escena_2":
		print("saltar a escena 2 desde Dialogic")
		get_tree().change_scene_to_file("escena2.tscn")
	if argument== "ir_escena_3":
		print("saltar a escena 3 desde Dialogic")
		get_tree().change_scene_to_file("escena3.tscn")
	if argument== "ir_escena_1":
		print("saltar a escena 1 desde Dialogic")
		get_tree().change_scene_to_file("escena1.tscn")
		
		



# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_button_pressed() -> void:
	Dialogic.start("dialogo_sutemo")
