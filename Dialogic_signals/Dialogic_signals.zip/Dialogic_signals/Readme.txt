proyecto godoc-con-dialogic
----------------------------


Proyecto en blanco que contiene el plugin (addon) de Dialogic versión 19 
Godot v.4.6 modo Compatibilidad
addon->dialogic v.alfa 19


Mas información https://github.com/dialogic-godot/dialogic
Descaga en  https://dialogic.pro/

Qué es Dialogic y primeros pasos: https://github.com/mgea/godot/wiki/Dialogic-(Dialog-System)
