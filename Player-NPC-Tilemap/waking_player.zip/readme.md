walking_player 

---------------------

Diseño de un **player** listo para usar con movimiento 

Se puede importar/añadir  a otros proyectos copiando player.tscn, player.gd y las imagenes que están en spritesheet_frisk.png