extends CharacterBody2D


const speed = 500.0
var puntos = 0 # se van añadiendo cada vez que chocas con ogro




func get_input():
	var input_direction = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	velocity = input_direction*speed
	$AnimatedSprite2D.play("default") 
	if Input.is_action_pressed("ui_right"):
		$AnimatedSprite2D.play("move_dcha")
	if Input.is_action_pressed("ui_left"):
		$AnimatedSprite2D.play("move_izda")
	if Input.is_action_pressed("ui_up"):
		$AnimatedSprite2D.play("move_up")
	if Input.is_action_pressed("ui_down"):
		$AnimatedSprite2D.play("move_down")
	
		


func _physics_process(delta: float) -> void:
	# Add the gravity.
	get_input()
	var colision = move_and_collide(velocity * delta)

	# variable colision==true ha colisionado
	if colision:
		# Obtenemos el cuerpo real con el que chocamos
		var cuerpo = colision.get_collider()
		print("He chocado con: ", cuerpo.name)
		# Si el objeto es un RigidBody, le aplicamos un impulso
		if cuerpo is RigidBody2D:
			# Obtenemos el cuerpo real con el que chocamos
			# Calculamos la dirección del empuje (desde el jugador hacia el objeto)
			# El -colision.get_normal() nos da la dirección del impacto
			print("empujo")
			cuerpo.apply_central_impulse(-colision.get_normal() * 50.0)
		if cuerpo is StaticBody2D:
			print ("eliminando a ", cuerpo.name)
			cuerpo.hide() # no se ve pero ocupa espacio
			cuerpo.queue_free() # elimina
			puntos = puntos+1
			print ("puntos=",puntos)
				
	
		
